#ifndef CONFIG_H
#define CONFIG_H

// Impostazioni dello schermo
#define SCREEN_WIDTH 1280
#define SCREEN_HEIGHT 720

// Impostazioni del mondo di gioco
#define MAX_SQUARES 10
#define BASE_SCROLL_SPEED 300.0f
#define MAX_SCROLL_SPEED 800.0f

// Impostazioni del Player
#define PLAYER_START_X 200.0f
#define PLAYER_SPEED_Y 400.0f
#define AUTO_FORWARD_SPEED 50.0f

#endif
