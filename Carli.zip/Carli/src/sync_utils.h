#ifndef SYNC_UTILS_H
#define SYNC_UTILS_H

#include "game_state.h"

void InitSharedDataMutex(SharedData* data);
void DestroySharedDataMutex(SharedData* data);

// Funzioni da chiamare prima e dopo aver letto/scritto i dati
void LockData(SharedData* data);
void UnlockData(SharedData* data);

#endif
