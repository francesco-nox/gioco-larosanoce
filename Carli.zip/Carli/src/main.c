#include "raylib.h"
#include "config.h"
#include "game_state.h"
#include "sync_utils.h"
#include "player.h"
#include "enemy.h"
#include "obstacle.h"
#include "background_parallax.h"
#include "hud_manager.h"
#include <pthread.h>
#include <stdio.h>
#include <stdbool.h>

// Prototipi dei thread
void* PhysicsThreadFunction(void* arg);
void* SpawnerThreadFunction(void* arg);

int main(void) {
    // 1. Inizializzazione Finestra
    const int screenWidth = 1280;
    const int screenHeight = 720;
    InitWindow(screenWidth, screenHeight, "Endless Runner Multithread");

    // 2. Setup Dati Condivisi e Mutex
    SharedData sharedData = { 0 };
    InitSharedDataMutex(&sharedData);
    
    sharedData.currentState = STATE_MENU;
    sharedData.scrollSpeed = 300.0f;
    sharedData.playerRect = (Rectangle){ 200, (float)screenHeight / 2 - 25, 50, 50 };
    sharedData.enemyRect = (Rectangle){ 20, (float)screenHeight / 2 - 50, 80, 80 }; 
    sharedData.playerAlive = true;

    // 3. Caricamento Asset
    Texture2D background = LoadTexture("assets/background.png");
    Texture2D player = LoadTexture("assets/player.png");
    Texture2D enemy = LoadTexture("assets/enemy.png");

    pthread_t physicsThread, spawnerThread;
    bool threadsRunning = false;

    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        float dt = GetFrameTime(); 

        // --- INPUT & LOGICA DI STATO ---
        if (sharedData.currentState == STATE_MENU) {
            if (IsKeyPressed(KEY_ENTER)) {
                LockData(&sharedData);
                sharedData.currentState = STATE_PLAYING;
                UnlockData(&sharedData);

                if (!threadsRunning) {
                    pthread_create(&physicsThread, NULL, PhysicsThreadFunction, &sharedData);
                    pthread_create(&spawnerThread, NULL, SpawnerThreadFunction, &sharedData);
                    threadsRunning = true;
                }
            }
        } 
        else if (sharedData.currentState == STATE_PLAYING) {
            LockData(&sharedData);
            if (IsKeyDown(KEY_UP)) sharedData.playerRect.y -= 400.0f * dt;
            if (IsKeyDown(KEY_DOWN)) sharedData.playerRect.y += 400.0f * dt;
            
            if (sharedData.playerRect.y < 0) sharedData.playerRect.y = 0;
            if (sharedData.playerRect.y > screenHeight - sharedData.playerRect.height) 
                sharedData.playerRect.y = screenHeight - sharedData.playerRect.height;
            UnlockData(&sharedData);
        }
        else if (sharedData.currentState == STATE_GAMEOVER) {
            if (IsKeyPressed(KEY_R)) {
                LockData(&sharedData);
                sharedData.currentState = STATE_MENU; 
                sharedData.playerAlive = true;
                sharedData.score = 0;
                sharedData.scrollSpeed = 300.0f;
                sharedData.playerRect = (Rectangle){ 200, (float)screenHeight / 2 - 25, 50, 50 };
                sharedData.enemyRect = (Rectangle){ 20, (float)screenHeight / 2 - 50, 80, 80 };
                for (int i = 0; i < MAX_SQUARES; i++) sharedData.obstacles[i].active = false;
                UnlockData(&sharedData);
            }
        }

        // --- DRAWING (Thread Principale) ---
        BeginDrawing();
        ClearBackground(BLACK);

        // Disegniamo lo sfondo fuori dallo switch: sarà la base per ogni stato
        DrawBackground(background, &sharedData);

        switch (sharedData.currentState) {
            case STATE_MENU:
                DrawText("PREMI INVIO PER INIZIARE", screenWidth/2 - 150, screenHeight/2, 20, RAYWHITE);
                break;

            case STATE_PLAYING:
                DrawObstacles(&sharedData);

                LockData(&sharedData);
                DrawTexturePro(player, 
                    (Rectangle){ 0, 0, (float)player.width, (float)player.height },
                    sharedData.playerRect, (Vector2){ 0, 0 }, 0.0f, WHITE);
                UnlockData(&sharedData);

                DrawEnemy(enemy, &sharedData);
                DrawGameUI(&sharedData);
                break;

            case STATE_GAMEOVER:
                DrawText("GAME OVER", screenWidth/2 - 100, screenHeight/2 - 20, 40, RED);
                DrawText("PREMI 'R' PER RESET", screenWidth/2 - 100, screenHeight/2 + 30, 20, RAYWHITE);
                break;
        }

        EndDrawing();
    }

    // 4. Pulizia Finale
    UnloadTexture(background);
    UnloadTexture(enemy);
    UnloadTexture(player);
    DestroySharedDataMutex(&sharedData);
    CloseWindow();

    return 0;
}
