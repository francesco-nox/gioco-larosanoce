#include "obstacle.h"
#include "raylib.h"
#include "sync_utils.h"
#include "config.h"

void InitObstacles(SharedData* data) {
    LockData(data);
    
    for (int i = 0; i < MAX_SQUARES; i++) {
        // Grandezza variabile per rendere il gioco imprevedibile
        float size = (float)GetRandomValue(30, 80);
        
        data->obstacles[i].rect = (Rectangle){
            SCREEN_WIDTH + (i * 300.0f), // Spaziati di 300 pixel l'uno dall'altro all'inizio
            (float)GetRandomValue(0, SCREEN_HEIGHT - (int)size),
            size,
            size
        };
        
        // Colori freddi generati casualmente
        data->obstacles[i].color = (Color){ 
            GetRandomValue(50, 100), 
            GetRandomValue(100, 200), 
            GetRandomValue(200, 255), 
            255 
        };
        
        data->obstacles[i].speed = BASE_SCROLL_SPEED;
        data->obstacles[i].active = true;
    }
    
    UnlockData(data);
}

void DrawObstacles(SharedData* data) {
    LockData(data);
    
    for (int i = 0; i < MAX_SQUARES; i++) {
        if (data->obstacles[i].active) {
            DrawRectangleRec(data->obstacles[i].rect, data->obstacles[i].color);
            // Un bordino grigio per farli risaltare meglio sullo sfondo
            DrawRectangleLinesEx(data->obstacles[i].rect, 2, DARKGRAY);
        }
    }
    
    UnlockData(data);
}
