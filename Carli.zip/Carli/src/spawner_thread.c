#include "raylib.h"
#include "game_state.h"
#include "sync_utils.h"
#include "config.h"
#include <stdlib.h>
#include <unistd.h>

#define SCREEN_WIDTH 1280
#define SCREEN_HEIGHT 720
#define MAX_SPEED 800.0f
#define SPEED_INCREMENT 10.0f

void* SpawnerThreadFunction(void* arg) {
    SharedData* data = (SharedData*)arg;
    int lastScoreMilestone = 0;
    int sleepTimeMicroseconds = 50000; 

    while (1) {
        LockData(data);

        if (data->currentState != STATE_PLAYING) {
            UnlockData(data);
            usleep(sleepTimeMicroseconds);
            continue;
        }

        // 1. AUMENTO DIFFICOLTÀ
        if (data->score - lastScoreMilestone >= 500) {
            if (data->scrollSpeed < MAX_SPEED) {
                data->scrollSpeed += SPEED_INCREMENT;
            }
            lastScoreMilestone = data->score;
        }

        // 2. RICICLO OSTACOLI
        for (int i = 0; i < MAX_SQUARES; i++) {
            // Se l'ostacolo è uscito a sinistra o non è mai stato attivato
            if (!data->obstacles[i].active || (data->obstacles[i].rect.x + data->obstacles[i].rect.width < 0)) {
                
                float newSize = (float)(rand() % 51 + 30); // 30 a 80
                float offsetX = (float)(rand() % 251 + 50); // 50 a 300
                
                data->obstacles[i].active = true;
                data->obstacles[i].rect.x = SCREEN_WIDTH + offsetX;
                data->obstacles[i].rect.y = (float)(rand() % (SCREEN_HEIGHT - (int)newSize));
                data->obstacles[i].rect.width = newSize;
                data->obstacles[i].rect.height = newSize;
                
                data->obstacles[i].color = (Color){ 
                    (unsigned char)(rand() % 51 + 50),   // R 
                    (unsigned char)(rand() % 101 + 100), // G
                    (unsigned char)(rand() % 56 + 200),  // B
                    255 
                };
                
                data->obstacles[i].speed = data->scrollSpeed;
            }
        }

        UnlockData(data);
        usleep(sleepTimeMicroseconds);
    }
    return NULL;
}
