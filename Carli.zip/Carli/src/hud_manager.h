#ifndef HUD_MANAGER_H
#define HUD_MANAGER_H

#include "game_state.h"

void DrawMainMenuUI(void);
void DrawGameUI(SharedData* data);
void DrawGameOverUI(SharedData* data);

#endif
