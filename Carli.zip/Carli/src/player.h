#ifndef PLAYER_H
#define PLAYER_H

#include "game_state.h"

// Funzione comoda per riportare la navicella alla posizione iniziale
// da usare quando si passa dal Game Over a una nuova partita
void ResetPlayer(SharedData* data);

// Gestisce l'input da tastiera per l'asse Y.
// Attenzione: deve essere chiamata SOLO nel thread principale.
void UpdatePlayerInput(SharedData* data);

#endif
