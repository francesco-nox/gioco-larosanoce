#include "sync_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void InitSharedDataMutex(SharedData* data) {
    pthread_mutexattr_t attr;
    pthread_mutexattr_init(&attr);
    // Cruciale: permette al main di non auto-bloccarsi
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
    
    pthread_mutex_init(&data->mutex, &attr); // Usiamo .mutex
    
    pthread_mutexattr_destroy(&attr);
}

void DestroySharedDataMutex(SharedData* data) {
    pthread_mutex_destroy(&data->mutex); // Usiamo .mutex
}

void LockData(SharedData* data) {
    pthread_mutex_lock(&data->mutex); // Usiamo .mutex
}

void UnlockData(SharedData* data) {
    pthread_mutex_unlock(&data->mutex); // Usiamo .mutex
}
