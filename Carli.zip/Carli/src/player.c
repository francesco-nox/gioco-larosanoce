#include "player.h"
#include "raylib.h"
#include "sync_utils.h"
#include "config.h"

// Possiamo spostare questi valori in config.h in seguito
#define PLAYER_SPEED_Y 400.0f
#define SCREEN_HEIGHT 720

void ResetPlayer(SharedData* data) {
    // Prima di toccare i dati, chiediamo sempre il permesso al semaforo
    LockData(data);
    
    data->playerRect.x = 200.0f; // La posizione sicura a destra
    data->playerRect.y = (float)(SCREEN_HEIGHT / 2 - 25); // Al centro dello schermo
    data->playerAlive = true;
    
    UnlockData(data);
}

void UpdatePlayerInput(SharedData* data) {
    // Calcoliamo quanto tempo è passato dall'ultimo fotogramma disegnato
    float dt = GetFrameTime();
    
    // Variabile temporanea per calcolare di quanti pixel vogliamo spostarci
    float moveY = 0.0f;
    
    // Leggiamo la pressione dei tasti (Freccia Su/Giù oppure W/S)
    if (IsKeyDown(KEY_UP) || IsKeyDown(KEY_W)) {
        moveY -= PLAYER_SPEED_Y * dt;
    }
    if (IsKeyDown(KEY_DOWN) || IsKeyDown(KEY_S)) {
        moveY += PLAYER_SPEED_Y * dt;
    }
    
    // Se c'è stato effettivamente un input da parte del giocatore
    if (moveY != 0.0f) {
        
        // Chiudiamo l'accesso ai dati per evitare conflitti con il thread fisico
        LockData(data);
        
        data->playerRect.y += moveY;
        
        // Effettuiamo un controllo rigido sui bordi per mantenere la navicella visibile
        if (data->playerRect.y < 0) {
            data->playerRect.y = 0;
        } else if (data->playerRect.y + data->playerRect.height > SCREEN_HEIGHT) {
            data->playerRect.y = SCREEN_HEIGHT - data->playerRect.height;
        }
        
        // Rilasciamo i dati in modo che gli altri thread possano tornare a lavorarci
        UnlockData(data);
    }
}
