#ifndef BACKGROUND_PARALLAX_H
#define BACKGROUND_PARALLAX_H

#include "raylib.h"
#include "game_state.h"

// Funzione esposta per disegnare lo sfondo in loop
void DrawBackground(Texture2D texture, SharedData* data);

#endif
