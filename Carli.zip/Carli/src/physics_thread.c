#include "raylib.h"
#include "game_state.h"
#include "sync_utils.h"
#include "config.h"
#include <unistd.h> 

#define PLAYER_MAX_X 200.0f
#define AUTO_FORWARD_SPEED 60.0f
#define ENEMY_LERP_SPEED 2.5f 

void* PhysicsThreadFunction(void* arg) {
    SharedData* data = (SharedData*)arg;
    float dt = 0.016f; 

    while (1) {
        LockData(data);
        GameState currentState = data->currentState;
        
        if (currentState != STATE_PLAYING) {
            UnlockData(data);
            usleep(16000); 
            continue;
        }

        // 1. MOVIMENTO DEL PLAYER
        // Gestito dal main.c per l'input, qui potresti aggiungere gravità in futuro.

        // 2. SCORRIMENTO DELLO SFONDO (Rimosso)
        // data->backgroundScrolling non viene più aggiornato perché lo sfondo è statico.

        bool isColliding = false;

        // 3. SCORRIMENTO OSTACOLI E COLLISIONI
        for (int i = 0; i < MAX_SQUARES; i++) {
            if (data->obstacles[i].active) {
                data->obstacles[i].rect.x -= data->obstacles[i].speed * dt;

                if (CheckCollisionRecs(data->playerRect, data->obstacles[i].rect)) {
                    isColliding = true;
                    data->playerRect.x -= data->obstacles[i].speed * dt;
                }
            }
        }

        // 4. RECUPERO POSIZIONE (Auto-forward)
        if (!isColliding && data->playerRect.x < PLAYER_MAX_X) {
            data->playerRect.x += AUTO_FORWARD_SPEED * dt;
        }

        // 5. LOGICA DELL'INSEGUITORE (L'Amico)
        float targetY = data->playerRect.y;
        data->enemyRect.y += (targetY - data->enemyRect.y) * ENEMY_LERP_SPEED * dt;
        data->enemyRect.x = 20.0f; 

        // 6. CONDIZIONE DI GAME OVER
        if (CheckCollisionRecs(data->playerRect, data->enemyRect) || data->playerRect.x <= 0) {
            data->playerAlive = false;
            data->currentState = STATE_GAMEOVER;
        }

        // 7. PUNTEGGIO
        data->score += 1; 

        UnlockData(data);
        usleep(16000); 
    }

    return NULL;
}
