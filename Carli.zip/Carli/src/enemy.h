#ifndef ENEMY_H
#define ENEMY_H

#include "game_state.h"

void UpdateEnemyLogic(SharedData* data);
void DrawEnemy(Texture2D photo, SharedData* data);

#endif
