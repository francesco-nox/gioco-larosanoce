#include "hud_manager.h"
#include "raylib.h"
#include "sync_utils.h"
#include "config.h"

void DrawMainMenuUI(void) {
    DrawText("ENDLESS RUNNER", SCREEN_WIDTH / 2 - 140, SCREEN_HEIGHT / 2 - 50, 40, RAYWHITE);
    DrawText("PREMI INVIO PER INIZIARE", SCREEN_WIDTH / 2 - 150, SCREEN_HEIGHT / 2 + 20, 20, LIGHTGRAY);
}

void DrawGameUI(SharedData* data) {
    // Leggiamo il punteggio in sicurezza
    LockData(data);
    int currentScore = data->score;
    UnlockData(data);

    DrawText(TextFormat("PUNTI: %d", currentScore), 20, 20, 30, RAYWHITE);
}

void DrawGameOverUI(SharedData* data) {
    LockData(data);
    int finalScore = data->score;
    UnlockData(data);

    // Un rettangolo nero semitrasparente per fare l'effetto "schermo oscurato"
    DrawRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, Fade(BLACK, 0.7f));
    
    DrawText("GAME OVER", SCREEN_WIDTH / 2 - 120, SCREEN_HEIGHT / 2 - 60, 50, RED);
    DrawText(TextFormat("PUNTEGGIO FINALE: %d", finalScore), SCREEN_WIDTH / 2 - 130, SCREEN_HEIGHT / 2, 20, RAYWHITE);
    DrawText("PREMI 'R' PER RIPROVARE", SCREEN_WIDTH / 2 - 130, SCREEN_HEIGHT / 2 + 50, 20, LIGHTGRAY);
}
