#ifndef GAME_STATE_H
#define GAME_STATE_H

#include "raylib.h"
#include <pthread.h>
#include <stdbool.h>

// Definizione degli stati del gioco
typedef enum {
    STATE_MENU,
    STATE_PLAYING,
    STATE_GAMEOVER
} GameState;

// Definizione del singolo ostacolo
typedef struct {
    Rectangle rect;
    Color color;
    float speed;
    bool active;
} Obstacle;

#define MAX_SQUARES 10

// IL DATABASE CENTRALE
typedef struct {
    // Lucchetto per la sincronizzazione
    pthread_mutex_t mutex;

    // Stato generale
    GameState currentState;
    int score;
    float scrollSpeed;
    float backgroundScrolling;

    // Entità (Ecco cosa mancava!)
    Rectangle playerRect;
    Rectangle enemyRect; // <--- Aggiungi questa riga
    bool playerAlive;

    // Array degli ostacoli
    Obstacle obstacles[MAX_SQUARES];

} SharedData;

#endif
