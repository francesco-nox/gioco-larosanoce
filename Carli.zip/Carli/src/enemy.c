#include "enemy.h"
#include "raylib.h"
#include "config.h"
#include "sync_utils.h"

#define ENEMY_X_POSITION 10.0f  // Fisso sul bordo sinistro
#define ENEMY_LERP_SPEED 2.0f   // Quanto velocemente segue il player in verticale

void UpdateEnemyLogic(SharedData* data) {
    float dt = 0.016f; // Delta time fisso per il thread fisico
    
    LockData(data);
    // L'inseguitore segue dolcemente la Y del player (Interpolazione lineare)
    // Questo lo rende più "vivo" invece di essere un pezzo di legno fisso
    float targetY = data->playerRect.y;
    data->enemyRect.y += (targetY - data->enemyRect.y) * ENEMY_LERP_SPEED * dt;
    
    // Impostiamo la X fissa
    data->enemyRect.x = ENEMY_X_POSITION;
    UnlockData(data);
}

void DrawEnemy(Texture2D photo, SharedData* data) {
    LockData(data);
    Rectangle dest = data->enemyRect;
    UnlockData(data);

    // Disegniamo la foto dell'amico dentro il rettangolo dell'enemy
    // Usiamo DrawTexturePro per assicurarci che la foto si adatti al quadrato
    DrawTexturePro(photo, 
        (Rectangle){ 0, 0, (float)photo.width, (float)photo.height },
        dest, 
        (Vector2){ 0, 0 }, 0.0f, WHITE);
}
