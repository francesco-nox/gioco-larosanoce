#ifndef OBSTACLE_H
#define OBSTACLE_H

#include "game_state.h"

// Inizializza i quadrati la prima volta che si avvia la partita
void InitObstacles(SharedData* data);

// Disegna i quadrati attivi sullo schermo
void DrawObstacles(SharedData* data);

#endif
