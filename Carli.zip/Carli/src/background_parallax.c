#include "raylib.h"
#include "game_state.h"
#include "sync_utils.h"
#include "background_parallax.h"

void DrawBackground(Texture2D texture, SharedData* data) {
    // Disegniamo la texture adattandola perfettamente alla risoluzione 1280x720.
    // DrawTexturePro permette di definire un rettangolo di destinazione:
    // se l'immagine è piccola, viene ingrandita fino a coprire tutto lo schermo.
    
    DrawTexturePro(
        texture, 
        (Rectangle){ 0, 0, (float)texture.width, (float)texture.height }, // Sorgente (tutta l'immagine)
        (Rectangle){ 0, 0, 1280, 720 },                                 // Destinazione (tutto lo schermo)
        (Vector2){ 0, 0 },                                              // Origine (angolo in alto a sinistra)
        0.0f,                                                           // Rotazione
        WHITE                                                           // Tinta (nessuna)
    );
}
