#include "raylib.h"

int main(){
	InitWindow(800, 450, "Hello raylib!");
	SetTargetFPS(60);
	while(!WindowShouldClose){

	}
}
